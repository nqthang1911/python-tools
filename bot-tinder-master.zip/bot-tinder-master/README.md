# bot-tinder
bot tinder

video 
https://www.youtube.com/watch?v=0lOAj4SAQjw&lc=z22ad52jhza1cn04004t1aokgx4xtugzgnw00xqk2ch5rk0h00410
